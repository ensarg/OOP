package tr.edu.sehir.oop;

public class EchoServer {

    public static void main(String[] args) {
        ServerT sT = new ServerT();
        sT.startServerT();
    }
}
