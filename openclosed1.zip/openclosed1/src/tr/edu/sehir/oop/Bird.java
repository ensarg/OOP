package tr.edu.sehir.oop;

public class Bird extends Animal1 {
    public void birdSing() {
        System.out.println("bird: singing\n");
    }
}
