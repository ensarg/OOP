package tr.edu.sehir.oop;

public class Cat2 extends Animal2 {
    public void makeSound(){
        System.out.println("cat: mew mew\n");
    }
}
