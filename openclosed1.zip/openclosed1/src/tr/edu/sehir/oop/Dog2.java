package tr.edu.sehir.oop;

public class Dog2 extends Animal2 {
    public void makeSound(){
        System.out.println("dog: hav hav\n");
    }
}
