package tr.edu.sehir.oop;

public abstract class Animal2 {
    public abstract void makeSound();
}
