package tr.edu.sehir.oop;

public class Animal1 {

}
