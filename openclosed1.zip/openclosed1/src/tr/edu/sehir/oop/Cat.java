package tr.edu.sehir.oop;

public class Cat extends Animal1 {
    public void mew() {
        System.out.println("cat: mew mew\n");
    }
}
