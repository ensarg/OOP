package tr.edu.sehir.oop;

public class Dog extends Animal1 {
    public void bark() {
        System.out.println("dog:hav hav\n");
    }
}
