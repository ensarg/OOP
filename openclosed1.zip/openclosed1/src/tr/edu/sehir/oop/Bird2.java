package tr.edu.sehir.oop;

public class Bird2 extends Animal2 {
   public void makeSound(){
      System.out.println("bird is singing\n");
   }
}
